"""Network communication"""
