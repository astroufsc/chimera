"""Operating system utilties including:
- Extensions to os.path for splitting a path into component pieces
  and searching for lists of files that match a particular criteria.
- Etilties for finding the user's preferences file folder and such.
"""
from OSUtil import *
from getDirs import *
