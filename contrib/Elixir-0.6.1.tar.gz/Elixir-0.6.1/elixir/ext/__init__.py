'''
Ext package

Additional Elixir statements and functionality.
'''
