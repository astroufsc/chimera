
/* WCSLIB library version number. */
#define WCSLIB_VERSION 4.3

/* 64-bit integer data type. */
#define WCSLIB_INT64 long long int
