"""
$LastChangedBy: mkuemmel $ 
$LastChangedDate: 2006-12-20 09:35:13 +0000 (Wed, 20 Dec 2006) $
$HeadURL: http://astropy.scipy.org/svn/astrolib/trunk/asciidata/Lib/__init__.py $
"""
__version__ = "Version 1.1 $LastChangedRevision: 123 $"

from asciifunction import *
